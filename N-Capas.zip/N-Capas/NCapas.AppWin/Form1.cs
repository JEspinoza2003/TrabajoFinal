using NCapas.Dominio;
using NCapas.Logic;

namespace NCapas.AppWin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cargarDatos();
        }
        private void cargarDatos()
        {
            var listado = PrestamoBL.Listar();
            listado.Insert(0, new Prestamo
            {
                Numero = "--SELECCIONE--"
            });
            cboPre.DataSource = listado;
            cboPre.DisplayMember = "Numero";
            cboPre.ValueMember = "ID";
        }

       

        private void btnConsulta_Click(object sender, EventArgs e)
        {

            int listar = cboPre.SelectedIndex;
            switch (listar)
            {
                case 0:
                    txtCliente.Text = cboPre.ValueMember = "IdCliente";
                    break;
            }
        }

        private void Form1_Load_1(object sender, EventArgs e)
        {
            cargarDatos();
        }

        private void Form1_Load_2(object sender, EventArgs e)
        {
            cargarDatos();
        }

    }
}