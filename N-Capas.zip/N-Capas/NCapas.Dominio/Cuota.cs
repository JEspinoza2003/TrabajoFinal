﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCapas.Dominio
{
    public class Cuota
    {
        public int NroCuota { get; set; }

        public DateTime FechaVencimiento { get; set; }

        public decimal Intereses { get; set; }

        public decimal PagoTotal { get; set; }

    }
}
