﻿using NCapas.Data;
using NCapas.Dominio;

namespace NCapas.Logic
{
    public class PrestamoBL
    {
        public static List<Prestamo> Listar()
        {
            var prestamodata = new PrestamoData();
            return prestamodata.Listar();
        }
        public static Prestamo BuscarPorId(int id)
        {
            var prestamoData = new PrestamoData();
            return prestamoData.BuscarPorId(id);
        }
        public static bool Actualizar(Prestamo prestamo)
        {
            return true;
        }

        
    }
}