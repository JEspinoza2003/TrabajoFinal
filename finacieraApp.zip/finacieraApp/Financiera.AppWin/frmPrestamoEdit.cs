﻿using Financiera.Dominio;
using Financiera.Logic;
using System;
using System.IO;
using System.Windows.Forms;

namespace Financiera.AppWin
{
    public partial class frmPrestamoEdit : Form
    {
        public frmPrestamoEdit()
        {
            InitializeComponent();
        }

        private void iniciarFormulario(object sender, EventArgs e)
        {
            cargarDatos();  
        }

        private void cargarDatos()
        {
            var listado = PrestamoBL.Listar();
            listado.Insert(0, new Prestamo
            {
                Numero = "--SELECCIONE--"
            });
            cboPrestamo.DataSource = listado;
            cboPrestamo.DisplayMember = "Numero";
            cboPrestamo.ValueMember = "ID";
        }
        private void GrabarDatos()
        {
            StreamWriter archivo = new StreamWriter("consulta.txt", true);
            archivo.WriteLine(txtCliente.Text);
            archivo.WriteLine(txtImporte.Text);
            archivo.WriteLine(txtPlazo.Text);
            archivo.WriteLine(txtTaza.Text);
            archivo.Close();
        }

        private void verCuotas(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void btnConsulta_Click(object sender, EventArgs e)
        {
            GrabarDatos();
        }
    }
}
